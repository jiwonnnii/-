package UI.HOME;

import javax.swing.JDialog;

public class ChatUI extends JDialog {

}
