package UI.HOME;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Main.MemberMain;
import VO.MemberVO;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.UIManager;
import java.awt.Font;

public class HomeUI extends JFrame implements ActionListener {
	
	private SearchTwoPlaceUI searchTwoPlaceUI;
	private FriendUI friendUI ;			// 친구 페이지
	private JLabel myID_lb=new JLabel("");
	private FavoriteUI favoriteUI;
	private JTabbedPane tabbedPane;
	private MemberVO myInfo=null;		// 로그인한 나의 정보가 들어가 있음
	private JButton logout_btn ;	    // 로그아웃
	MemberVO me=null;// = new MemberVO();
	private MemberMain mm ;				
	private JLabel lblNewLabel;


	public HomeUI(MemberVO mem) {
		
		getContentPane().setBackground(new Color(230, 230, 250));			
		this.myInfo = mem;// mem : 내정보
		System.out.println(mem.getMemState()+"로그인");
		System.out.println(myInfo.getMemState()+"로그인");
		setSize(1274,800);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(47, 54, 1169, 654);
		getContentPane().add(tabbedPane);
		
		searchTwoPlaceUI = new SearchTwoPlaceUI(myInfo);
		tabbedPane.addTab("중간찾기", null, searchTwoPlaceUI, null);
		
		favoriteUI = new FavoriteUI(myInfo);
		tabbedPane.addTab("즐겨찾기", null, favoriteUI, null);
		
		friendUI = new FriendUI(myInfo);
		tabbedPane.addTab("친구목록", null, friendUI, null);
		
		myID_lb = new JLabel("");
		myID_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		myID_lb.setBounds(823, 56, 304, 25);
		getContentPane().add(myID_lb);
		myID_lb.setBackground(Color.WHITE);
		myID_lb.setHorizontalAlignment(SwingConstants.RIGHT);
		myID_lb.setText(myInfo.getMemID()+" 회원님 환영합니다! ");
		
		logout_btn = new JButton(""); // 로그아웃
		logout_btn.setIcon(new ImageIcon(HomeUI.class.getResource("/images/LOGOUT.png")));
		logout_btn.setBounds(1136, 42, 80, 30);
		getContentPane().add(logout_btn);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(HomeUI.class.getResource("/images/girl2.png")));
		lblNewLabel.setBounds(889, 10, 62, 62);
		getContentPane().add(lblNewLabel);
		logout_btn.addActionListener(this);

		//pack();
		setVisible(false);
	
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {					// 로그아웃!
		if(e.getSource() == logout_btn) {
			mm = new MemberMain();
			
			//myInfo.setMemState("0");
			mm.updateLoginState2(myInfo.getMemID());
			
			mm.showLoginAgain();
			

	
		}
		
		
	}
}
