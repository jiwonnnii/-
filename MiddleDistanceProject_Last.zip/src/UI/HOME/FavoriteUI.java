package UI.HOME;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import DAO.FavoriteDAO;
import VO.FavoriteListValueVO;
import VO.FavoriteVO;
import VO.MemberVO;
import VO.PlaceVO;

import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class FavoriteUI extends JPanel implements ActionListener, ListSelectionListener{
	private JPanel favoritePanel;
	private JList favorite_list;
	private FavoriteDAO favoriteDao = new FavoriteDAO();
	private ArrayList<FavoriteListValueVO> FavoriteListValueVO_aList = new ArrayList<>();
	private ArrayList<FavoriteVO> favorite_aList ;
	private JButton btnNewButton;
	private MemberVO myInfo = null;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel label_1;
	private JLabel label;
	private JLabel label_2;
	public FavoriteUI(MemberVO mem) {
		setBackground(Color.WHITE);
		setSize(1220, 640);
		setLayout(null);
		
		this.myInfo = mem;
		
		favoritePanel = new JPanel();
		favoritePanel.setBackground(Color.WHITE);
		favoritePanel.setBounds(160, 30, 909, 513);
		add(favoritePanel);
		favoritePanel.setLayout(null);
		

		 FavoriteListValueVO_aList = favoriteDao.favoriteListValueSQL(myInfo.getMemID());
			for (int i = 0; i < FavoriteListValueVO_aList.size(); i++) {
				System.out.println(FavoriteListValueVO_aList.get(i));
			}

		JScrollPane scrollpane = new JScrollPane();
		favorite_list = new JList();
		favorite_list.setBackground(new Color(230, 230, 250));
		favorite_list.setFont(new Font("굴림", Font.PLAIN, 11));
		
	    favorite_list.setListData(FavoriteListValueVO_aList.toArray());
			
		scrollpane.setViewportView(favorite_list);
		favoritePanel.add(scrollpane);
		scrollpane.setBounds(61, 103, 777, 386);

		
		btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(FavoriteUI.class.getResource("/images/새로고침btn.png")));
		btnNewButton.setBounds(718, 54, 120, 30);
		btnNewButton.addActionListener(this);
		favoritePanel.add(btnNewButton);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(FavoriteUI.class.getResource("/images/route.png")));
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setBounds(641, 28, 65, 65);
		favoritePanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(FavoriteUI.class.getResource("/images/그림1.png")));
		lblNewLabel_1.setBounds(71, 78, 22, 22);
		favoritePanel.add(lblNewLabel_1);
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(FavoriteUI.class.getResource("/images/그림1.png")));
		label_1.setBounds(98, 78, 22, 22);
		favoritePanel.add(label_1);
		
		label = new JLabel("");
		label.setBounds(98, 78, 22, 22);
		favoritePanel.add(label);
		
		label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(FavoriteUI.class.getResource("/images/그림1.png")));
		label_2.setBounds(125, 78, 22, 22);
		favoritePanel.add(label_2);
		
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==btnNewButton) {
			FavoriteListValueVO_aList = favoriteDao.favoriteListValueSQL(myInfo.getMemID());
			for (int i = 0; i < FavoriteListValueVO_aList.size(); i++) {
				System.out.println(FavoriteListValueVO_aList.get(i));
			}
			favoriteDao.test(myInfo.getMemID());
			favorite_list.setListData(FavoriteListValueVO_aList.toArray());
			

		}
	}
	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		if (!e.getValueIsAdjusting()) {
			if(e.getSource() == favorite_list&&favorite_list.getSelectedIndex()!=-1) {
				//setSelectedComponent(searchTwoPlaceUI)
			}	
		}
		
	}
}
