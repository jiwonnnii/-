package UI.LOGIN;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import DAO.MemberDAO;
import DAO.SearchTwoPlaceDao;
import Main.MemberMain;
import VO.MemberVO;
import VO.PlaceVO;

public class MemberUI extends JDialog implements ActionListener , ListSelectionListener {
	private JTextField memId_tf; 
	private JTextField memName_tf;
	private JTextField memAddr_tf;
	private JPasswordField memPw_tf;
	private JPasswordField memPwCheck_tf;
	
	private JLabel memPw_lb;
	private JLabel memPwCheck_lb;
	private JLabel memId_lb;
	private JLabel memName_lb;
	private JLabel memAddr_lb; 
	
	private JButton memIdCheck_btn; 	//중복검사 Button
	private JButton memAddrSearch_btn;	//주소검색 Button
	private JButton memInsert_btn;	 	//Member 가입
	private JButton memBack_btn;		//Member 가입 취소
	
	private JLabel explainId_lb;		//아이디 기입 설명 (5자리 이상)
	private JLabel explainPw_lb;		//비밀번호와 비밀번호확인 비교 설명
	private JLabel explainAddr_lb;
	private MemberDAO memDao;
	private MemberMain memMain = new MemberMain();
	
	private String memPlace; //list에서 선택된 주소 placeVO의 이름
	private JList addressList; // 주소 검색 list 

	public MemberUI() {
		memDao = new MemberDAO();
		getContentPane().setBackground(Color.WHITE);
		setSize(500, 500);
		getContentPane().setLayout(null);

		JLabel lblNewLabel_title = new JLabel("회원가입");
		lblNewLabel_title.setFont(new Font("나눔고딕 ExtraBold", Font.BOLD, 15));
		lblNewLabel_title.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_title.setHorizontalAlignment(JLabel.CENTER);
		lblNewLabel_title.setBounds(177, 24, 145, 52);
		getContentPane().add(lblNewLabel_title);

		memId_lb = new JLabel("\uC544\uC774\uB514");
		memId_lb.setHorizontalAlignment(SwingConstants.RIGHT);
		memId_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		memId_lb.setBounds(57, 92, 57, 15);
		getContentPane().add(memId_lb);

		memPw_lb = new JLabel("\uBE44\uBC00\uBC88\uD638");
		memPw_lb.setHorizontalAlignment(SwingConstants.RIGHT);
		memPw_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		memPw_lb.setBounds(57, 146, 57, 15);
		getContentPane().add(memPw_lb);

		memPwCheck_lb = new JLabel("\uBE44\uBC00\uBC88\uD638\uD655\uC778");
		memPwCheck_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		memPwCheck_lb.setBounds(47, 175, 84, 15);
		getContentPane().add(memPwCheck_lb);

		memName_lb = new JLabel("\uC774\uB984");
		memName_lb.setHorizontalAlignment(SwingConstants.RIGHT);
		memName_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		memName_lb.setBounds(57, 221, 57, 15);
		getContentPane().add(memName_lb);

		memId_tf = new JTextField();
		memId_tf.setBounds(133, 88, 145, 20);
		memId_tf.setText("");
		getContentPane().add(memId_tf);
		memId_tf.setColumns(10);

		memName_tf = new JTextField();
		memName_tf.setFont(new Font("굴림", Font.PLAIN, 11));
		memName_tf.setText("");
		memName_tf.setBounds(133, 218, 145, 20);
		getContentPane().add(memName_tf);
		memName_tf.setColumns(10);

		memIdCheck_btn = new JButton("\uC911\uBCF5\uAC80\uC0AC");
		memIdCheck_btn.setFont(new Font("굴림", Font.PLAIN, 11));
		memIdCheck_btn.setBounds(310, 87, 97, 23);
		getContentPane().add(memIdCheck_btn);
		memIdCheck_btn.addActionListener(this);

		memAddr_tf = new JTextField();
		memAddr_tf.setFont(new Font("굴림", Font.PLAIN, 11));
		memAddr_tf.setBounds(133, 248, 145, 20);
		memAddr_tf.setText("");
		getContentPane().add(memAddr_tf);
		memAddr_tf.setColumns(15);

		memAddr_lb = new JLabel("\uC8FC\uC18C");
		memAddr_lb.setHorizontalAlignment(SwingConstants.RIGHT);
		memAddr_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		memAddr_lb.setBounds(57, 251, 57, 15);
		getContentPane().add(memAddr_lb);

		memAddrSearch_btn = new JButton("\uC8FC\uC18C\uAC80\uC0C9");
		memAddrSearch_btn.setFont(new Font("굴림", Font.PLAIN, 11));
		memAddrSearch_btn.setBounds(310, 247, 97, 23);
		getContentPane().add(memAddrSearch_btn);
		memAddrSearch_btn.addActionListener(this);

		memInsert_btn = new JButton("\uC644\uB8CC");
		memInsert_btn.setFont(new Font("굴림", Font.PLAIN, 11));
		memInsert_btn.setBounds(106, 418, 97, 23);
		getContentPane().add(memInsert_btn);
		memInsert_btn.addActionListener(this);

		memBack_btn = new JButton("\uCDE8\uC18C");
		memBack_btn.setFont(new Font("굴림", Font.PLAIN, 11));
		memBack_btn.setBounds(281, 418, 97, 23);
		getContentPane().add(memBack_btn);
		memBack_btn.addActionListener(this);

		explainId_lb = new JLabel("\uC544\uC774\uB514\uB294 5\uC790\uB9AC \uC774\uC0C1");
		explainId_lb.setHorizontalAlignment(SwingConstants.CENTER);
		explainId_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		explainId_lb.setForeground(Color.BLACK);
		explainId_lb.setBounds(152, 119, 170, 15);
		getContentPane().add(explainId_lb);

		explainPw_lb = new JLabel("");
		explainPw_lb.setHorizontalAlignment(SwingConstants.CENTER);
		explainPw_lb.setFont(new Font("굴림", Font.PLAIN, 11));
		explainPw_lb.setForeground(Color.RED);
		explainPw_lb.setBounds(177, 199, 145, 20);
		getContentPane().add(explainPw_lb);

		memPw_tf = new JPasswordField();
		memPw_tf.setBounds(133, 142, 145, 20);
		memPw_tf.setText("");
		getContentPane().add(memPw_tf);

		memPwCheck_tf = new JPasswordField();
		memPwCheck_tf.setFont(new Font("굴림", Font.PLAIN, 11));
		memPwCheck_tf.setBounds(133, 172, 145, 20);
		memPwCheck_tf.setText("");
		getContentPane().add(memPwCheck_tf);
		
		
		addressList = new JList();
		addressList.setFont(new Font("굴림", Font.PLAIN, 11));
		JScrollPane scrollPane = new JScrollPane(addressList);
		scrollPane.setViewportView(addressList);
		scrollPane.setBounds(108, 291, 271, 117);
		addressList.addListSelectionListener(this);
		getContentPane().add(scrollPane);
		
		explainAddr_lb = new JLabel();
		explainAddr_lb.setBounds(108, 388, 62, 18);
		getContentPane().add(explainAddr_lb);
		
		setVisible(false);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String id = memId_tf.getText();
		char[] pass1 = memPw_tf.getPassword();
		char[] pass2 = memPwCheck_tf.getPassword();
		String password11 = new String(pass1);
		String password22 = new String(pass2);

		if (e.getSource() == memIdCheck_btn) { // 아이디 중복검사

			if (memId_tf.getText().equals("")) { // 빈칸일때
				
				explainId_lb.setText("아이디를 입력해주세요.");
			} else {
				
				
				if (memId_tf.getText().length() < 5) { // 아이디가 5자리 아래일 때
					explainId_lb.setForeground(Color.RED);
					explainId_lb.setText("5자리 이상 입력해주세요!");
				} else {
					
					
					if (memDao.IDcheck(id) == 0) { // IDcheck==true라면
						// id = memId_tf.getText();
						String name = memName_tf.getText();
						String address = memAddr_tf.getText();
						explainId_lb.setForeground(Color.BLACK);
						explainId_lb.setText("사용가능한 아이디입니다.");

						MemberVO vo = new MemberVO();
						/* vo.setMemberID(id); */

					}
					if (memDao.IDcheck(id) == 1) {
						explainId_lb.setForeground(Color.RED);
						explainId_lb.setText("이미 존재하는 아이디 입니다.");
					}
				}

			}

		}
		//주소검색 버튼 클릭시 
		if(e.getSource() == memAddrSearch_btn) {
			String memAddr = memAddr_tf.getText();
			SearchTwoPlaceDao  searchTwoPlaceDao = new SearchTwoPlaceDao();
			ArrayList<PlaceVO> addr_alist = searchTwoPlaceDao.receivekakaoMapAPI(memAddr);
			if(addr_alist!=null) {
				addressList.setListData(addr_alist.toArray());
			}
		}
		 //회원가입 완료버튼 클릭 시
		if (e.getSource() == memInsert_btn) {
			if(memId_tf.getText().equals("") || password22.equals("") || password11.equals("")
					|| memName_tf.getText().equals("") || memAddr_tf.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "빈 폼이 있습니다!");
			}else { 
				if(!password11.equals(password22)) {
					explainPw_lb.setForeground(Color.RED);
					explainPw_lb.setText("비밀번호확인이 실패!");
				} else {
					explainPw_lb.setForeground(Color.black);
					explainPw_lb.setText("비밀번호확인 성공");
					if(explainAddr_lb.getText().equals("주소등록") && memPlace.equals(memAddr_tf.getText())) {
							if (explainId_lb.getText().equals("사용가능한 아이디입니다.")) {
								String name = memName_tf.getText();
								String address = memAddr_tf.getText();
		
								MemberVO vo = new MemberVO();
								vo.setMemID(id);
								vo.setMemPW(password11);
								vo.setMemName(name);
								vo.setMemAddress(address);
								vo.setMemState("0"); //state 0: 로그오프  , 1: 로그인
								memDao.insertMember(vo);
								JOptionPane.showMessageDialog(null, "회원이 되신 것을 환영합니다!");
								memMain.showLogin();
							} else if(!explainId_lb.getText().equals("사용가능한 아이디입니다.")){
								
								JOptionPane.showMessageDialog(null, "아이디 중복검사를 해주세요");
								
							} else {
								JOptionPane.showMessageDialog(null, "아이디를 다시 설정해주세요!");
							}
					}else {
						
						JOptionPane.showMessageDialog(null,memPlace+memAddr_tf.getText()+"주소를 제대로 입력해주세요!");
					}
				}
			}

		//회원가입 취소 버튼 클릭시
		} else if (e.getSource() == memBack_btn) { 

			//취소 -> 다시 로그인 화면으로 전환
			memMain.showLogin();
		}

	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		if(!e.getValueIsAdjusting()) {
			
			if(e.getSource() == addressList && addressList.getSelectedIndex() != -1) {
				
				memPlace = ((PlaceVO) addressList.getSelectedValue()).getPlaceName();
				System.out.println(memPlace);
				memAddr_tf.setText(memPlace);
				explainAddr_lb.setText("주소등록");
			}
				
		}
	}
}
